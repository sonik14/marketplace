create function check_insert()
  returns trigger
language plpgsql
as $$
DECLARE
          avail boolean;
          system integer;
          seller_id integer;
          quarter_o_id integer;
          resale boolean;
        BEGIN
          IF NEW.buyer_id = NEW.seller_id THEN
            RAISE EXCEPTION 'You cannot sell an item to your company!';
          ELSEIF (NEW.quarter_o_id<=NEW.quarter_id) OR (NEW.quarterM<NEW.quarter_o_id) THEN
                RAISE EXCEPTION 'Program Error! Quarter obtained is not in the future!';
          END IF;
          avail = (SELECT avail FROM prod_chars WHERE id=NEW.prod_id);
          IF avail = true THEN
            RAISE EXCEPTION 'Program Error! The selected product is not RnD and cannot be sold!';
          ELSEIF NEW.quarter_id < avail THEN
            RAISE EXCEPTION 'Program Error! The selected product is not available yet!';
          END IF;
  
          system = (SELECT MIN(id) FROM companies);
          IF NEW.seller_id!=system THEN
            seller_id = NULL;
            SELECT id, quarter_o_id, saleRightsB INTO seller_id, quarter_o_id, resale FROM comp_rnds
                WHERE buyer_id=NEW.seller_id AND prod_id=NEW.prod_id AND cancelled=false AND signedS=true AND signedB=true;
            IF seller_id IS NULL THEN
              RAISE EXCEPTION 'You cannot sell an item that you do not possess!';
            ELSEIF resale IS FALSE THEN
              RAISE EXCEPTION 'You do not have the rights to sell this RnD';
            ELSEIF NEW.quarter_o_id < quarter_o_id THEN
              RAISE EXCEPTION 'RnD will not be ready the time you want to sell it.
 Please change the quarter!';           
            END IF;
          END IF;
  
  
          IF (SELECT id FROM comp_rnds WHERE
              seller_id=NEW.seller_id AND buyer_id=NEW.buyer_id AND prod_id=NEW.prod_id AND cancelled=false) IS NOT NULL OR
              (SELECT id FROM comp_rnds WHERE
              seller_id=NEW.buyer_id AND buyer_id=NEW.seller_id AND prod_id=NEW.prod_id AND cancelled=false) IS NOT NULL THEN
            RAISE EXCEPTION 'There is another contract in progress for the same product and between the same companies!';
          END IF;
        END;
$$;

